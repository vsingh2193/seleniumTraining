package Driver;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LaunchDriver {

	public static void readDriver(String Path, String URL) {
		System.setProperty("webdriver.chrome.driver", Path);
	    WebDriver driver = new ChromeDriver();
	    driver.get(URL);
	    driver.manage().window().maximize();
	    
	    //"https://www.redbus.in/"
	    //"C:\\Users\\Priti Singh\\eclipse-workspace\\Selenium_Framework\\seleniumDriver\\chromedriver.exe"
	    
	  	    
	    
	}

}
