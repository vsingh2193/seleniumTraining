package Redbus.com;

import java.io.IOException;
import Driver.LaunchDriver;
import Driver.resusable;

public class bookingRegistration {
	
	
	public static void main(String[] args) throws IOException {
		 LaunchDriver.readDriver("D:\\eclipse\\Selenium_Framework\\selenium_Driver\\chromedriver.exe", resusable.url1);
		 LaunchDriver.maximizeBrowser();
		 bookingPageActions.firstname();
		 bookingPageActions.lastname();
		 bookingPageActions.phone();
		 bookingPageActions.username();
		 bookingPageActions.address();
		 bookingPageActions.city();
		 bookingPageActions.state();
		 bookingPageActions.postalcode();
		 bookingPageActions.email();
		 bookingPageActions.password();
		 bookingPageActions.confirmPassword();
		 bookingPageActions.submit();

}
}