package Redbus.com;

import org.testng.annotations.Test;

import Driver.LaunchDriver;

public class LaunchBrowser{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//LaunchDriver launch= new LaunchDriver();
		//LaunchDriver.readDriver("https://www.redbus.in/", "C:\\Users\\Priti Singh\\eclipse-workspace\\Selenium_Framework\\seleniumDriver\\chromedriver.exe");
		
	
	
	    //@Test
	    //public void launchBrowser() {
		LaunchDriver.readDriver("C:\\Users\\Priti Singh\\eclipse-workspace\\Selenium_Framework\\seleniumDriver\\chromedriver.exe","https://www.redbus.in/");
}

}



