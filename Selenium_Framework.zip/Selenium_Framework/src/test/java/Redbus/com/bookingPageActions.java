package Redbus.com;

import java.io.IOException;

import org.openqa.selenium.By;

import Driver.LaunchDriver;
import readInputTestData.readerFile;

public class bookingPageActions {
	
public static void firstname() throws IOException {
		
	    //LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("contact.information.firstname.input"))).click();
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("contact.information.firstname.input"))).sendKeys("Vivek");
	}

public static void lastname() throws IOException {
	
	LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("contact.information.lastname.input"))).sendKeys("Singh");
}

public static void phone() throws IOException {
	
	LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("contact.information.phone.input"))).sendKeys("987654321");
}
public static void username() throws IOException {
	
	LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("contact.information.username.input"))).sendKeys("vsingh75");
}

public static void address() throws IOException {
	
	LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("Mailing.information.address.input"))).sendKeys("TestingAddress");
}
public static void city() throws IOException {
	
	LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("Mailing.information.city.input"))).sendKeys("Bangalore");
}

public static void state() throws IOException {
	
	LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("Mailing.information.state.input"))).sendKeys("Karnataka");
}
public static void postalcode() throws IOException {
	
	LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("Mailing.information.postalCode.input"))).sendKeys("560037");
}
public static void email() throws IOException {
	
	LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("User.Information.email.input"))).sendKeys("testemail@gmail.com");
}
public static void password() throws IOException {
	
	LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("User.Information.password.input"))).sendKeys("Test1234@");
}
public static void confirmPassword() throws IOException {
	
	LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("User.Information.confirmPassword.input"))).sendKeys("Test1234@");
}
public static void submit() throws IOException {
	
	LaunchDriver.driver.findElement(By.xpath(readerFile.readORProperties("User.Information.submit.input"))).click();;
}



}
