package Redbus.com;

import java.io.IOException;

import org.testng.annotations.Test;

import Driver.LaunchDriver;
import Driver.resusable;
import seleniumActions.seleniumUIActions;

public class launchBrowser{

  
 
 public static void main(String[] args) throws IOException {
	 LaunchDriver.readDriver("D:\\eclipse\\Selenium_Framework\\selenium_Driver\\chromedriver.exe", resusable.url);
	 LaunchDriver.maximizeBrowser();
	 seleniumUIActions.enterName();
	 //seleniumUIActions.
	 //LaunchDriver.closebrowser();
	
}
		


	
	

}
